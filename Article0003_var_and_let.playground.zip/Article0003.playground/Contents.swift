let helloBox = "hello"
var worldBox = "world"

print( helloBox + ", " + worldBox )

worldBox = "earth"
print( helloBox + ", " + worldBox )
